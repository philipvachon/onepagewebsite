# One Page Website
This is the page website, made for my Front-End Development Course. I wanted to practice with content-based media queries, material design, jQuery, and web design in general.
