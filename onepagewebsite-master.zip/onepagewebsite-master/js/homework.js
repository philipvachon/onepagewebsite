var name = "Philip"

function homework(number) {
	return(number + 2 - 5);
};
